# exceptions.py
"""Custom exceptions for the member management package."""

class InvalidMemberDataError(Exception):
    """Raised when a member record contains malformed data."""
    pass
