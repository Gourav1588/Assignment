import re
from .exceptions import InvalidMemberDataError

EMAIL_PATTERN = re.compile(r'^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$')
PHONE_PATTERN = re.compile(r'^\d{3}-\d{4}$')


def clean_string(value):
    if not isinstance(value, str):
        raise InvalidMemberDataError(f"Expected a string, got {type(value).__name__}")
    cleaned = value.strip()
    if not cleaned:
        raise InvalidMemberDataError("Value cannot be empty.")
    return cleaned


def validate_email(email):
    email = clean_string(email)
    if not EMAIL_PATTERN.match(email):
        raise InvalidMemberDataError(f"Invalid email for member: '{email}'")
    return email


def validate_phone(phone):
    phone = clean_string(phone)
    if not PHONE_PATTERN.match(phone):
        raise InvalidMemberDataError(f"Invalid phone number: '{phone}'")
    return phone
