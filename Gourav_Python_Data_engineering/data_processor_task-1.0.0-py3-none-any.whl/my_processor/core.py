from .utils import clean_string, validate_email, validate_phone
from .exceptions import InvalidMemberDataError


class Member:
    def __init__(self, name, email, phone):
        self.name = clean_string(name)
        self.email = validate_email(email)
        self.phone = validate_phone(phone)

    def __repr__(self):
        return f"Member(name='{self.name}', email='{self.email}', phone='{self.phone}')"

    def __str__(self):
        return f"{self.name} <{self.email}> ({self.phone})"


def process_raw_members(raw_members):
    members = []
    for raw in raw_members:
        print(f"Processing member: {raw.get('name', 'Unknown')}...", end=" ")
        try:
            member = Member(raw.get("name"), raw.get("email"), raw.get("phone"))
            members.append(member)
            print("Validation Successful.")
        except InvalidMemberDataError as e:
            print(f"Skipping.\nError: {e}")
        except (KeyError, ValueError) as e:
            print(f"Skipping.\nStandard error: {e}")

    print(f"Summary: {len(members)} members processed successfully.")
    return members


def filter_members_by_domain(members, domain):
    return list(filter(lambda m: m.email.endswith(domain), members))


def get_all_names(members):
    return list(map(lambda m: m.name, members))
