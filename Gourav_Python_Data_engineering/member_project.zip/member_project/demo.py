
from my_processor import process_raw_members, filter_members_by_domain, get_all_names

raw_members = [
    {"name": "Priya Sharma", "email": "priya.sharma@gmail.com", "phone": "555-2048"},
    {"name": "Arjun Mehta", "email": "arjun.mehta@outlook.com", "phone": "555-3391"},
    {"name": "Sara Williams", "email": "sara.williams@gmail.com", "phone": "555-7712"},
    {"name": "Rohit Verma", "email": "rohit.verma@gmail.com", "phone": "not-a-phone"},
    {"name": "Emily Clarke", "email": "emily.clarke.example.com", "phone": "555-4420"},
    {"name": "David Kim", "email": "david.kim@yahoo.com", "phone": "555-6689"},
]

if __name__ == "__main__":
    members = process_raw_members(raw_members)

    print("\nAll processed members:")
    for m in members:
        print(" -", m)

    print("\nNames only (map/lambda):", get_all_names(members))

    gmail_members = filter_members_by_domain(members, "gmail.com")
    print("Members @gmail.com (filter/lambda):", gmail_members)
